/* ============================================================
 * app.js —— Capa de interacción (shell del sitio de la galería, solo depende del SDK MoodMates + MM_I18N)
 *
 * Responsabilidades:
 *   Hero de apertura (personaje de línea semioculto + auto-giro de entrada + pausa en viewport)
 *   Fila de personajes (personajes originales, clicar para cambiar toda la galería)
 *   Doble vista (muro / pasillo de álbum) + paginación con flechas / teclado
 *   Pestañas de agrupación, flujo de miniaturas, recorrido automático
 *   Cajón de configuración (personaje / línea de boceto / recorrido / simulación AI / importar/exportar)
 *   Bilingüe chino/inglés, temas claro/oscuro, persistencia en localStorage
 * ============================================================ */
(function () {
  'use strict';

  var MM = window.MoodMates;
  var I = window.MM_I18N;
  var $ = function (id) { return document.getElementById(id); };

  /* ---------------- Lectura y escritura de preferencias ---------------- */
  var PREF_KEY = 'mm.prefs';
  var prefs = { lang: 'es', theme: 'dark', mode: 'wall', character: 'nimbo', sketch: false, tourMs: 2500, variants: {} };
  try {
    Object.assign(prefs, JSON.parse(localStorage.getItem(PREF_KEY) || '{}'));
  } catch (e) { /* preferencias dañadas, usar valores por defecto */ }
  if (!MM.characters.get(prefs.character)) prefs.character = MM.characters.defaultId();
  if (!prefs.variants || typeof prefs.variants !== 'object') prefs.variants = {};
  function savePrefs() {
    try { localStorage.setItem(PREF_KEY, JSON.stringify(prefs)); } catch (e) { /* modo privado, ignorar */ }
  }

  /* ---------------- Referencias DOM ---------------- */
  var elStage = $('stage');
  var elTips = $('tips');
  var elEmoId = $('emoId');
  var elEmoName = $('emoName');
  var elEmoDesc = $('emoDesc');
  var elPager = $('pager');
  var elTabs = $('tabs');
  var elThumbZone = $('thumbZone');
  var elThumbFlow = $('thumbFlow');
  var elCastRow = $('castRow');
  var elToast = $('toast');
  var elDrawer = $('drawer');
  var elDrawerMask = $('drawerMask');
  var elTourToggle = $('tourToggle');
  var elTourInterval = $('tourInterval');
  var elSketchToggle = $('sketchToggle');
  var elCharSelect = $('charSelect');
  var elVariantField = $('variantField');
  var elVariantSelect = $('variantSelect');
  var elAiInput = $('aiInput');
  var elLangToggle = $('langToggle');
  var elThemeToggle = $('themeToggle');

  /* ---------------- Estado del sitio ---------------- */
  var currentTab = 'all';
  var selectedId = '02';
  var thumbs = [];            /* [{ id, def, engine, cell, nameSpan }] */
  var cellById = new Map();
  var castCards = [];         /* [{ id, btn, nameEl, indEl, ch }] */
  var main = null;
  var hero = null;
  var tipsTimer = 0;
  var toastTimer = 0;
  var lastErrorAt = -1;

  /* ---------------- Utilidades de texto ---------------- */
  function dispName(def) {
    return I.lang === 'en' && def.en && def.en.name ? def.en.name : def.name;
  }
  function dispDesc(def) {
    return I.lang === 'en' && def.en && def.en.desc ? def.en.desc : (def.desc || '');
  }
  function groupName(g) {
    return I.lang === 'en' ? (g.en || g.name) : g.name;
  }
  function charName(ch) {
    return I.lang === 'en' && ch.en && ch.en.name ? ch.en.name : ch.name;
  }

  /* ---------------- Toast ---------------- */
  function toast(text, kind) {
    clearTimeout(toastTimer);
    elToast.textContent = text;
    elToast.className = 'toast show' + (kind ? ' ' + kind : '');
    toastTimer = setTimeout(function () { elToast.className = 'toast'; }, 3600);
  }

  /* ---------------- Burbuja de tips ---------------- */
  function showTips(text) {
    clearTimeout(tipsTimer);
    elTips.textContent = text;
    elTips.classList.add('show');
    tipsTimer = setTimeout(function () { elTips.classList.remove('show'); }, 3200);
  }

  /* ---------------- Seguimiento de mirada: pointermove a nivel window, caché de rectángulo 200ms ---------------- */
  var gazeTargets = [];
  function watchGaze(engine, el) {
    gazeTargets.push({ engine: engine, el: el, rect: null, rectAt: 0 });
  }
  function unwatchGaze(el) {
    gazeTargets = gazeTargets.filter(function (t) { return t.el !== el; });
  }
  function refreshGazeRects() {
    gazeTargets.forEach(function (t) { t.rect = null; });
  }
  function clamp06(v) { return v < -0.6 ? -0.6 : (v > 0.6 ? 0.6 : v); }
  /* P1: el puntero llega a >100 Hz; el trabajo real (lectura de rects + setGaze sobre
   * todas las instancias) se coalescea a un máximo de 1 por fotograma en el próximo rAF,
   * evitando hasta ~5x getBoundingClientRect forzado por evento en pantallas de alta tasa. */
  var pendingPointer = null, gazeRaf = 0;
  function flushGaze() {
    gazeRaf = 0;
    var e = pendingPointer;
    if (!e) return;
    pendingPointer = null;
    var now = performance.now();
    for (var i = 0; i < gazeTargets.length; i++) {
      var t = gazeTargets[i];
      if (!t.rect || now - t.rectAt > 200) {
        t.rect = t.el.getBoundingClientRect();
        t.rectAt = now;
      }
      var r = t.rect;
      if (!r.width || !r.height) continue;
      t.engine.setGaze(
        clamp06((e.clientX - (r.left + r.width / 2)) / r.width) / 0.6,
        clamp06((e.clientY - (r.top + r.height / 2)) / r.height) / 0.6
      );
    }
  }
  window.addEventListener('pointermove', function (e) {
    /* coords en crudo: no retener objetos Event (conserva referencias nativas) */
    pendingPointer = { clientX: e.clientX, clientY: e.clientY };
    if (!gazeRaf) gazeRaf = requestAnimationFrame(flushGaze);
  }, { passive: true });
  document.addEventListener('pointerleave', function () {
    gazeTargets.forEach(function (t) { t.engine.clearGaze(); });
  });
  window.addEventListener('resize', refreshGazeRects, { passive: true });
  window.addEventListener('scroll', refreshGazeRects, { passive: true });

  /* ---------------- Personaje principal (reconstruir instancia al cambiar de personaje) ---------------- */
  function createMain(charId) {
    var emotion = main ? main.emotionId : selectedId;
    if (main) {
      main.destroy();
      unwatchGaze(elStage);
    }
    main = MM.create(elStage, {
      character: charId,
      variant: prefs.variants[charId] || '',
      emotion: emotion,
      idle: { standbyAfter: 60000, sleepAfter: 180000 },
      label: I.t('stageLabel')
    });
    main.setStyle({ sketch: elSketchToggle.checked ? 1 : 0 });
    main.on('change', function (e) {
      selectedId = e.id;
      updateMeta(e.def);
      highlightSelected();
      centerSelected();
    });
    main.on('tips', function (e) { showTips(e.text); });
    main.on('error', function (e) { lastErrorAt = performance.now(); toast(e.message, 'danger'); });
    watchGaze(main, elStage);
    window.MM_MAIN = main;   /* punto de acceso de depuración en consola */
  }

  /* ---------------- Cambio de personaje ---------------- */
  function switchCharacter(charId, opts) {
    opts = opts || {};
    if (!MM.characters.get(charId)) return;
    prefs.character = charId;
    savePrefs();
    if (main && main.touring) stopTourUI();
    createMain(charId);
    buildThumbs();
    fillVariantSelect();
    highlightCast();
    if (elCharSelect.value !== charId) {
      elCharSelect.value = charId;
      refreshDD();
    }
    if (!opts.silent) {
      toast(I.t('toastCharacter', { name: charName(MM.characters.get(charId)) }), 'ok');
    }
  }

  function highlightCast() {
    castCards.forEach(function (c) {
      c.btn.classList.toggle('selected', c.id === prefs.character);
    });
  }

  function buildCast() {
    elCastRow.innerHTML = '';
    castCards = [];
    MM.characters.list().forEach(function (ch) {
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'cast';

      var avatar = document.createElement('div');
      avatar.className = 'cast-avatar';
      btn.appendChild(avatar);

      var nameEl = document.createElement('span');
      nameEl.className = 'cast-name';
      btn.appendChild(nameEl);

      var indEl = document.createElement('span');
      indEl.className = 'cast-industry';
      btn.appendChild(indEl);

      elCastRow.appendChild(btn);

      var engine = MM.create(avatar, {
        character: ch.id,
        emotion: '02',
        lite: true,
        eyeScale: 1.35,
        label: ch.name
      });
      watchGaze(engine, avatar);

      btn.addEventListener('click', function () {
        if (!engine.signature || !engine.signature(0.7)) engine.spin(1);
        if (prefs.character !== ch.id) switchCharacter(ch.id);
      });

      castCards.push({ id: ch.id, btn: btn, nameEl: nameEl, indEl: indEl, ch: ch });
    });
    relabelCast();
    highlightCast();
  }

  function relabelCast() {
    castCards.forEach(function (c) {
      c.nameEl.textContent = charName(c.ch);
      c.indEl.textContent = I.t('industry_' + c.ch.industry);
      c.btn.title = charName(c.ch) + ' · ' + I.t('castClick');
    });
  }

  /* ---------------- Metadatos + paginación ---------------- */
  function currentDefs() {
    return MM.config.list(currentTab === 'all' ? null : currentTab);
  }
  function selectedIndex() {
    var defs = currentDefs();
    for (var i = 0; i < defs.length; i++) if (defs[i].id === selectedId) return i;
    return -1;
  }
  function updateMeta(def) {
    if (!def) def = MM.config.getRaw(selectedId);
    if (!def) return;
    elEmoId.textContent = 'ID ' + def.id;
    elEmoName.textContent = dispName(def);
    elEmoDesc.textContent = dispDesc(def);
    var defs = currentDefs();
    var idx = selectedIndex();
    elPager.textContent = (idx >= 0 ? String(idx + 1).padStart(2, '0') : '--') +
      ' / ' + String(defs.length).padStart(2, '0');
  }

  function highlightSelected() {
    cellById.forEach(function (cell, id) {
      cell.classList.toggle('selected', id === selectedId);
    });
  }

  /* ---------------- Vista de imagen en muro (modal) ---------------- */
  function stageOpen() { return document.body.classList.contains('stage-open'); }
  function openStage() {
    if (!document.body.classList.contains('mode-wall') || stageOpen()) return;
    document.body.classList.add('stage-open');
    refreshGazeRects();
  }
  function closeStage() {
    if (!stageOpen()) return;
    document.body.classList.remove('stage-open');
    refreshGazeRects();
  }
  $('stageClose').addEventListener('click', closeStage);
  document.querySelector('.stage-zone').addEventListener('click', function (e) {
    if (e.target === e.currentTarget) closeStage();
  });

  /* Centrar miniatura seleccionada: calcular desplazamiento con rectángulo de viewport,
     evitar que offsetParent trague el margen izquierdo */
  function centerSelected() {
    var cell = cellById.get(selectedId);
    if (!cell) return;
    var zr = elThumbZone.getBoundingClientRect();
    var cr = cell.getBoundingClientRect();
    if (document.body.classList.contains('mode-album')) {
      elThumbZone.scrollTo({
        left: elThumbZone.scrollLeft + (cr.left + cr.width / 2) - (zr.left + zr.width / 2),
        behavior: 'smooth'
      });
    } else {
      var nextTop = elThumbZone.scrollTop + (cr.top + cr.height / 2) - (zr.top + zr.height / 2);
      if (cr.top < zr.top || cr.bottom > zr.bottom) {
        elThumbZone.scrollTo({
          top: nextTop,
          behavior: 'smooth'
        });
      }
    }
  }

  /* ---------------- Paginación izquierda/derecha ---------------- */
  function step(delta) {
    var defs = currentDefs();
    if (!defs.length) return;
    if (main.touring) stopTourUI();
    var idx = selectedIndex();
    var next = idx < 0
      ? (delta > 0 ? 0 : defs.length - 1)
      : (idx + delta + defs.length) % defs.length;
    main.setEmotion(defs[next].id);
    openStage();
  }
  $('navPrev').addEventListener('click', function () { step(-1); });
  $('navNext').addEventListener('click', function () { step(1); });

  document.addEventListener('keydown', function (e) {
    var tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'SELECT' || tag === 'TEXTAREA') return;
    if (e.key === 'ArrowLeft') { step(-1); e.preventDefault(); }
    else if (e.key === 'ArrowRight') { step(1); e.preventDefault(); }
    else if (e.key === 'Escape') {
      if (closeAllDD()) return;
      if (elDrawer.classList.contains('open')) closeDrawer();
      else closeStage();
    }
  });

  /* ---------------- Desplegable personalizado ---------------- */
  var ddList = [];

  function enhanceSelect(sel) {
    var dd = document.createElement('div');
    dd.className = 'dd';
    sel.parentNode.insertBefore(dd, sel);
    dd.appendChild(sel);

    var trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = 'dd-trigger';
    trigger.setAttribute('aria-haspopup', 'listbox');
    trigger.setAttribute('aria-expanded', 'false');
    var pop = document.createElement('div');
    pop.className = 'dd-pop';
    pop.setAttribute('role', 'listbox');
    dd.appendChild(trigger);
    dd.appendChild(pop);

    function rebuild() {
      pop.innerHTML = '';
      Array.prototype.forEach.call(sel.options, function (opt) {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'dd-item' + (opt.value === sel.value ? ' selected' : '');
        btn.setAttribute('role', 'option');
        btn.setAttribute('aria-selected', opt.value === sel.value ? 'true' : 'false');
        var label = document.createElement('span');
        label.textContent = opt.textContent;
        btn.appendChild(label);
        var check = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
        check.setAttribute('class', 'dd-check');
        check.setAttribute('viewBox', '0 0 24 24');
        check.setAttribute('width', '14');
        check.setAttribute('height', '14');
        check.innerHTML = '<path d="M20 6L9 17l-5-5" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"/>';
        btn.appendChild(check);
        btn.addEventListener('click', function () {
          close();
          if (sel.value !== opt.value) {
            sel.value = opt.value;
            sel.dispatchEvent(new Event('change'));
          }
          rebuild();
        });
        pop.appendChild(btn);
      });
      var cur = sel.options[sel.selectedIndex];
      trigger.textContent = cur ? cur.textContent : '';
    }

    function close() {
      dd.classList.remove('open');
      trigger.setAttribute('aria-expanded', 'false');
    }
    function open() {
      closeAllDD();
      rebuild();
      dd.classList.add('open');
      trigger.setAttribute('aria-expanded', 'true');
    }
    trigger.addEventListener('click', function (e) {
      e.stopPropagation();
      if (dd.classList.contains('open')) close(); else open();
    });
    sel.addEventListener('change', rebuild);

    ddList.push({ dd: dd, rebuild: rebuild, close: close });
    rebuild();
  }

  function closeAllDD() {
    var any = false;
    ddList.forEach(function (i) {
      if (i.dd.classList.contains('open')) { any = true; i.close(); }
    });
    return any;
  }
  function refreshDD() {
    ddList.forEach(function (i) { i.rebuild(); });
  }
  document.addEventListener('click', function (e) {
    ddList.forEach(function (i) {
      if (!i.dd.contains(e.target)) i.close();
    });
  });

  /* ---------------- Pestañas de agrupación ---------------- */
  function tabList() {
    var groups = MM.config.groups().filter(function (g) {
      return MM.config.list(g.key).length > 0;
    });
    return [{ key: 'all', name: I.t('tabAll'), en: I.t('tabAll') }].concat(groups);
  }

  function buildTabs() {
    elTabs.innerHTML = '';
    tabList().forEach(function (g) {
      var count = g.key === 'all'
        ? MM.config.list().length
        : MM.config.list(g.key).length;
      var btn = document.createElement('button');
      btn.type = 'button';
      btn.className = 'tab' + (g.key === currentTab ? ' active' : '');
      btn.dataset.key = g.key;
      btn.innerHTML = '<span>' + groupName(g) + '</span><span class="tab-count">' + count + '</span>';
      btn.addEventListener('click', function () {
        if (currentTab === g.key) return;
        currentTab = g.key;
        Array.prototype.forEach.call(elTabs.children, function (t) {
          t.classList.toggle('active', t.dataset.key === g.key);
        });
        buildThumbs();
        updateMeta();
        if (main.touring) restartTour();
      });
      elTabs.appendChild(btn);
    });
  }

  /* ---------------- Flujo de miniaturas (muro de emojis del personaje actual) ---------------- */
  function buildThumbs() {
    thumbs.forEach(function (t) { t.engine.destroy(); });
    thumbs = [];
    cellById.clear();
    elThumbFlow.innerHTML = '';

    currentDefs().forEach(function (def) {
      var cell = document.createElement('div');
      cell.className = 'cell';
      cell.title = dispName(def) + ':' + dispDesc(def);

      var thumbEl = document.createElement('div');
      thumbEl.className = 'thumb';
      cell.appendChild(thumbEl);

      var label = document.createElement('div');
      label.className = 'cell-label';
      var cid = document.createElement('span');
      cid.className = 'cid';
      cid.textContent = def.id;
      var nameSpan = document.createElement('span');
      nameSpan.textContent = dispName(def);
      label.appendChild(cid);
      label.appendChild(nameSpan);
      cell.appendChild(label);

      /* Mini personaje: inactivo (costo cero frames), registrarse en el reloj compartido solo al pasar el ratón para reproducir animación */
      var engine = MM.create(thumbEl, {
        character: prefs.character,
        variant: prefs.variants[prefs.character] || '',
        emotion: def.id,
        autostart: false,
        label: dispName(def) + ' ' + I.t('thumbSuffix')
      });
      if (prefs.sketch) engine.setStyle({ sketch: 1 });

      cell.addEventListener('mouseenter', function () {
        engine.setActive(true);
        engine.replay();
      });
      cell.addEventListener('mouseleave', function () {
        engine.setActive(false);
        engine.setEmotion(def.id, { auto: true });
      });
      cell.addEventListener('click', function () {
        if (main.touring) stopTourUI();
        main.setEmotion(def.id);
        openStage();
      });

      elThumbFlow.appendChild(cell);
      thumbs.push({ id: def.id, def: def, engine: engine, cell: cell, nameSpan: nameSpan });
      cellById.set(def.id, cell);
    });

    highlightSelected();
    centerSelected();
  }

  /* ---------------- Pasillo de álbum: arrastrar con pulsación lateral para desplazarse ---------------- */
  (function () {
    var down = false, dragging = false, startX = 0, startLeft = 0, pid = 0;
    elThumbZone.addEventListener('pointerdown', function (e) {
      if (!document.body.classList.contains('mode-album')) return;
      down = true; dragging = false;
      startX = e.clientX;
      startLeft = elThumbZone.scrollLeft;
      pid = e.pointerId;
    });
    elThumbZone.addEventListener('pointermove', function (e) {
      if (!down) return;
      var dx = e.clientX - startX;
      if (!dragging && Math.abs(dx) > 6) {
        dragging = true;
        elThumbZone.classList.add('dragging');
        try { elThumbZone.setPointerCapture(pid); } catch (err) { /* puntero ya liberado */ }
      }
      if (dragging) elThumbZone.scrollLeft = startLeft - dx;
    });
    function endDrag() {
      down = false;
      if (dragging) {
        dragging = false;
        elThumbZone.classList.remove('dragging');
      }
    }
    elThumbZone.addEventListener('pointerup', endDrag);
    elThumbZone.addEventListener('pointercancel', endDrag);
  })();

  /* Cambio de idioma: actualizar etiquetas in situ, sin reconstruir la instancia del motor */
  function relabelThumbs() {
    thumbs.forEach(function (t) {
      t.nameSpan.textContent = dispName(t.def);
      t.cell.title = dispName(t.def) + ':' + dispDesc(t.def);
    });
  }

  /* ---------------- Modo de vista ---------------- */
  function setMode(mode) {
    prefs.mode = mode === 'album' ? 'album' : 'wall';
    savePrefs();
    document.body.classList.remove('stage-open');
    document.body.classList.toggle('mode-wall', prefs.mode === 'wall');
    document.body.classList.toggle('mode-album', prefs.mode === 'album');
    $('modeWall').classList.toggle('active', prefs.mode === 'wall');
    $('modeAlbum').classList.toggle('active', prefs.mode === 'album');
    refreshGazeRects();
    requestAnimationFrame(centerSelected);
  }
  $('modeWall').addEventListener('click', function () { setMode('wall'); });
  $('modeAlbum').addEventListener('click', function () { setMode('album'); });

  /* ---------------- Tema ---------------- */
  function setTheme(theme, silent) {
    prefs.theme = theme === 'light' ? 'light' : 'dark';
    savePrefs();
    document.documentElement.setAttribute('data-theme', prefs.theme);
    elThemeToggle.title = prefs.theme === 'dark' ? I.t('themeToLight') : I.t('themeToDark');
    if (!silent) toast(I.t(prefs.theme === 'dark' ? 'toastThemeDark' : 'toastThemeLight'));
  }
  elThemeToggle.addEventListener('click', function () {
    setTheme(prefs.theme === 'dark' ? 'light' : 'dark');
  });

  /* ---------------- Idioma ---------------- */
  function fillCharSelect() {
    elCharSelect.innerHTML = '';
    MM.characters.list().forEach(function (ch) {
      var opt = document.createElement('option');
      opt.value = ch.id;
      opt.textContent = charName(ch) + ' · ' + I.t('industry_' + ch.industry);
      elCharSelect.appendChild(opt);
    });
    elCharSelect.value = prefs.character;
  }

  /* ---- Variante de contorno corporal: mostrar solo para personajes que declararon variants ---- */
  function variantName(v) {
    return I.lang === 'en' && v.en && v.en.name ? v.en.name : v.name;
  }
  function fillVariantSelect() {
    var vs = MM.characters.variants(prefs.character);
    /* Limpiar IDs de variantes descontinuados que quedan en localStorage,
       evitar que el select muestre en blanco o se los pase al motor */
    var stored = prefs.variants[prefs.character] || '';
    if (stored && !vs.some(function (v) { return v.id === stored; })) {
      prefs.variants[prefs.character] = '';
      savePrefs();
    }
    if (!vs.length) {
      elVariantField.style.display = 'none';
      return;
    }
    elVariantField.style.display = '';
    elVariantSelect.innerHTML = '';
    var opt0 = document.createElement('option');
    opt0.value = '';
    opt0.textContent = I.t('variantDefault');
    elVariantSelect.appendChild(opt0);
    vs.forEach(function (v) {
      var opt = document.createElement('option');
      opt.value = v.id;
      opt.textContent = variantName(v);
      elVariantSelect.appendChild(opt);
    });
    elVariantSelect.value = prefs.variants[prefs.character] || '';
    refreshDD();
  }

  function applyI18n() {
    I.set(prefs.lang);
    document.documentElement.lang = prefs.lang === 'en' ? 'en' : 'es';
    document.title = I.t('docTitle');
    var nodes = document.querySelectorAll('[data-i18n]');
    for (var i = 0; i < nodes.length; i++) {
      nodes[i].textContent = I.t(nodes[i].getAttribute('data-i18n'));
    }
    elLangToggle.textContent = I.t('langBtn');
    $('settingsToggle').title = I.t('settingsBtn');
    $('drawerClose').setAttribute('aria-label', I.t('drawerClose'));
    $('navPrev').title = I.t('prevEmotion');
    $('navNext').title = I.t('nextEmotion');
    $('stageClose').title = I.t('stageClose');
    elThemeToggle.title = prefs.theme === 'dark' ? I.t('themeToLight') : I.t('themeToDark');
    buildTabs();
    relabelThumbs();
    relabelCast();
    updateMeta();
    fillCharSelect();
    fillVariantSelect();
    refreshDD();
  }
  elLangToggle.addEventListener('click', function () {
    prefs.lang = prefs.lang === 'es' ? 'en' : 'es';
    savePrefs();
    applyI18n();
    refreshGazeRects();
  });

  /* ---------------- Cajón de configuración ---------------- */
  function openDrawer() {
    elDrawer.classList.add('open');
    elDrawer.setAttribute('aria-hidden', 'false');
    elDrawerMask.hidden = false;
    requestAnimationFrame(function () { elDrawerMask.classList.add('show'); });
  }
  function closeDrawer() {
    closeAllDD();
    elDrawer.classList.remove('open');
    elDrawer.setAttribute('aria-hidden', 'true');
    elDrawerMask.classList.remove('show');
    setTimeout(function () { elDrawerMask.hidden = true; }, 300);
  }
  $('settingsToggle').addEventListener('click', openDrawer);
  $('drawerClose').addEventListener('click', closeDrawer);
  elDrawerMask.addEventListener('click', closeDrawer);

  /* ---------------- Recorrido automático ---------------- */
  function restartTour() {
    var ids = currentDefs().map(function (d) { return d.id; });
    main.startTour(ids, prefs.tourMs);
  }
  function stopTourUI() {
    main.stopTour();
    elTourToggle.checked = false;
  }
  function tabName(key) {
    var t = tabList().find(function (g) { return g.key === key; });
    return t ? groupName(t) : key;
  }
  elTourToggle.addEventListener('change', function () {
    if (elTourToggle.checked) {
      restartTour();
      openStage();
      toast(I.t('toastTourOn', { name: tabName(currentTab), n: currentDefs().length }), 'ok');
    } else {
      main.stopTour();
      toast(I.t('toastTourOff'));
    }
  });
  elTourInterval.addEventListener('change', function () {
    prefs.tourMs = parseInt(elTourInterval.value, 10) || 2500;
    savePrefs();
    if (main.touring) restartTour();
  });

  /* ---------------- Línea de boceto / personaje ---------------- */
  elSketchToggle.addEventListener('change', function () {
    prefs.sketch = elSketchToggle.checked;
    savePrefs();
    var sv = prefs.sketch ? 1 : 0;
    main.setStyle({ sketch: sv });
    /* La línea de boceto también afecta a las miniaturas de previsualización */
    thumbs.forEach(function (t) { t.engine.setStyle({ sketch: sv }); });
    toast(I.t(prefs.sketch ? 'toastSketchOn' : 'toastSketchOff'), prefs.sketch ? 'ok' : '');
  });

  elCharSelect.addEventListener('change', function () {
    if (elCharSelect.value !== prefs.character) switchCharacter(elCharSelect.value);
  });

  elVariantSelect.addEventListener('change', function () {
    prefs.variants[prefs.character] = elVariantSelect.value;
    savePrefs();
    if (main.touring) stopTourUI();
    createMain(prefs.character);
    buildThumbs();
    var cur = elVariantSelect.options[elVariantSelect.selectedIndex];
    toast(I.t('toastVariant', { name: cur ? cur.textContent : '' }), 'ok');
  });

  /* ---------------- Simulación de conexión AI ---------------- */
  function sendAI() {
    var raw = elAiInput.value.trim();
    if (!raw) return;
    if (main.touring) stopTourUI();
    var before = performance.now();
    var ok = main.handleAIMessage(raw);
    if (ok) openStage();
    if (ok && lastErrorAt < before) toast(I.t('toastAiSent') + ': ' + raw, 'ok');
  }
  $('aiSend').addEventListener('click', sendAI);
  elAiInput.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') sendAI();
  });
  $('aiSampleErr').addEventListener('click', function () {
    elAiInput.value = '{"emotionId":"34","tips":"Falló la llamada a la API, comprobar la red"}';
    sendAI();
  });
  $('aiSampleBad').addEventListener('click', function () {
    elAiInput.value = '{"emotionId":"99","tips":"Este es un ID de emoción inexistente"}';
    sendAI();
  });

  /* ---------------- Exportar / importar configuración ---------------- */
  $('btnExport').addEventListener('click', function () {
    var blob = new Blob([MM.config.exportConfig()], { type: 'application/json' });
    var a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'mood-mates-config.json';
    a.click();
    URL.revokeObjectURL(a.href);
    toast(I.t('toastExported', { n: MM.config.list().length }), 'ok');
  });
  var elImportFile = $('importFile');
  $('btnImport').addEventListener('click', function () { elImportFile.click(); });
  elImportFile.addEventListener('change', function () {
    var file = elImportFile.files[0];
    if (!file) return;
    var reader = new FileReader();
    reader.onload = function () {
      var res = MM.config.importConfig(String(reader.result));
      buildTabs();
      buildThumbs();
      updateMeta();
      if (res.ok) toast(I.t('toastImportOk', { n: res.added }), 'ok');
      else toast(I.t('toastImportFail', { n: res.added, err: res.errors.join('；') }), 'danger');
    };
    reader.readAsText(file);
    elImportFile.value = '';
  });

  /* ---------------- Logotipo de marca: instancia mini en la barra superior ---------------- */
  function buildBrand() {
    var elBrand = $('brandBall');
    var brand = MM.create(elBrand, {
      character: MM.characters.defaultId(),
      emotion: '02',
      lite: true,
      eyeScale: 1.7,
      label: 'Mood Mates'
    });
    watchGaze(brand, elBrand);
    elBrand.addEventListener('click', function () {
      if (!brand.signature || !brand.signature(0.6)) brand.spin(1);
    });
  }

  /* ---------------- Hero de apertura: personaje de línea semioculto ---------------- */
  function buildHero() {
    hero = MM.create($('heroBot'), {
      character: prefs.character,
      emotion: '02',
      label: 'Mood Mates'
    });
    hero.setStyle({ sketch: 1 });
    watchGaze(hero, $('heroBot'));

    /* Entrar con la acción de firma (sin firma, retroceder a girar); después las antics de espera de '02' se disparan periódicamente */
    setTimeout(function () {
      if (!hero.signature || !hero.signature(1)) hero.spin(2);
    }, 700);

    $('heroBot').addEventListener('click', function () {
      if (!hero.signature || !hero.signature(0.8)) hero.spin(1);
    });

    if ('IntersectionObserver' in window) {
      new IntersectionObserver(function (entries) {
        hero.setActive(entries[0].isIntersecting);
      }, { threshold: 0.05 }).observe($('hero'));
    }

    $('heroCta').addEventListener('click', function () {
      $('gallery').scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
  }

  /* ---------------- Interacción del escenario ---------------- */
  elStage.addEventListener('click', function () {
    /* Nimbo: al clicar celebrar sopla burbujas (sin cambiar de emoción); Twinkle: firma + cuerpo + confeti */
    if (main.celebrate) main.celebrate(1);
    else if (!main.signature || !main.signature(1)) main.spin(1);
  });

  /* Cualquier interacción del usuario reinicia el temporizador de espera
   * FIX v22b: guarda nula — si la creación principal falló antes (p. ej. excepción en
   * setEmotion), `main` es null y estos listeners globales inundaban la consola. */
  ['pointerdown', 'keydown'].forEach(function (evt) {
    document.addEventListener(evt, function () { if (main) main.resetIdle(); }, { passive: true });
  });

  /* ---------------- Inicialización ---------------- */
  function init() {
    I.set(prefs.lang);
    setTheme(prefs.theme, true);
    setMode(prefs.mode);
    elSketchToggle.checked = !!prefs.sketch;
    elTourInterval.value = String(prefs.tourMs);
    if (!elTourInterval.value) { elTourInterval.value = '2500'; prefs.tourMs = 2500; }
    fillCharSelect();
    enhanceSelect(elCharSelect);
    enhanceSelect(elVariantSelect);
    enhanceSelect(elTourInterval);

    createMain(prefs.character);
    buildCast();
    buildBrand();
    buildHero();
    applyI18n();
    buildThumbs();
    updateMeta();
    highlightSelected();
  }

  /* Catálogo externo opcional: si existe data/emotions.json se aplica antes de arrancar.
   * loadFromUrl nunca rechaza: ante cualquier fallo seguimos con el seed embebido.
   * En file:// (sin servidor) o sin fetch, iniciamos directamente. */
  function boot() {
    var url = window.MM_EMOTIONS_URL || 'data/emotions.json';
    if (location.protocol === 'file:' || typeof fetch !== 'function') { init(); return; }
    MM.config.loadFromUrl(url).then(function (r) {
      if (!r.ok && r.added === 0 && r.errors && r.errors.length &&
          String(r.errors[0]).indexOf('HTTP') === 0) {
        /* 404 u otro error de red: comportamiento normal sin catálogo externo */
      } else if (!r.ok) {
        console.warn('[MoodMates] ' + url + ' no aplicado del todo, se conserva el seed embebido para lo inválido:', r.errors);
      }
      init();
    });
  }
  boot();
})();